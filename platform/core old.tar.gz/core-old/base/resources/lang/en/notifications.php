<?php

return [
    'notifications' => 'Notifications',
    'mark_as_read' => 'Mark all as read',
    'clear' => 'Clear',
    'no_notification_here' => 'No notifications here',
    'please_check_again_later' => 'Please check again later',
    'view_more' => 'View more...',
    'view' => 'View',
    'next' => 'Next',
    'previous' => 'Previous',
];
