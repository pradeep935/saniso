<x-core::empty-state :title="trans('No items')" :subtitle="trans('There is no items to display.')" />
