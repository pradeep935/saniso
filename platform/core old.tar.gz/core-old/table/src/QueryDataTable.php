<?php

namespace Botble\Table;

use Yajra\DataTables\QueryDataTable as BaseQueryDataTable;

class QueryDataTable extends BaseQueryDataTable
{
}
