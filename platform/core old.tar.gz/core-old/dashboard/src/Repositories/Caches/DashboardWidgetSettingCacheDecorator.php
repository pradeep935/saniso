<?php

namespace Botble\Dashboard\Repositories\Caches;

use Botble\Dashboard\Repositories\Eloquent\DashboardWidgetSettingRepository;

/**
 * @deprecated
 */
class DashboardWidgetSettingCacheDecorator extends DashboardWidgetSettingRepository
{
}
