<?php

namespace Botble\Dashboard\Repositories\Caches;

use Botble\Dashboard\Repositories\Eloquent\DashboardWidgetRepository;

/**
 * @deprecated
 */
class DashboardWidgetCacheDecorator extends DashboardWidgetRepository
{
}
